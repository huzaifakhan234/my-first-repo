﻿namespace mobileShop
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.Panel1 = new System.Windows.Forms.Panel();
            this.btnCancel = new Guna.UI2.WinForms.Guna2Button();
            this.btnVerify = new Guna.UI2.WinForms.Guna2Button();
            this.txtPassword = new Guna.UI2.WinForms.Guna2TextBox();
            this.btnMinimize = new Guna.UI2.WinForms.Guna2Button();
            this.btnDeletePhone = new Guna.UI2.WinForms.Guna2Button();
            this.btnCustomerRecords = new Guna.UI2.WinForms.Guna2Button();
            this.btnStock = new Guna.UI2.WinForms.Guna2Button();
            this.btnCustomers = new Guna.UI2.WinForms.Guna2Button();
            this.btnAddNewPhone = new Guna.UI2.WinForms.Guna2Button();
            this.btnExit = new Guna.UI2.WinForms.Guna2Button();
            this.Panel2 = new System.Windows.Forms.Panel();
            this.guna2Elipse1 = new Guna.UI2.WinForms.Guna2Elipse(this.components);
            this.guna2Elipse2 = new Guna.UI2.WinForms.Guna2Elipse(this.components);
            this.guna2Elipse3 = new Guna.UI2.WinForms.Guna2Elipse(this.components);
            this.guna2Elipse4 = new Guna.UI2.WinForms.Guna2Elipse(this.components);
            this.guna2Elipse5 = new Guna.UI2.WinForms.Guna2Elipse(this.components);
            this.guna2Elipse6 = new Guna.UI2.WinForms.Guna2Elipse(this.components);
            this.uC_Login1 = new mobileShop.AllUserControl.UC_Login();
            this.uC_DeletePhoneRecord1 = new mobileShop.AllUserControl.UC_DeletePhoneRecord();
            this.uC_CustomerRecords1 = new mobileShop.AllUserControl.UC_CustomerRecords();
            this.uC_Stock1 = new mobileShop.AllUserControl.UC_Stock();
            this.uC_Customer1 = new mobileShop.AllUserControl.UC_Customer();
            this.uC_AddNewPhone1 = new mobileShop.AllUserControl.UC_AddNewPhone();
            this.Panel1.SuspendLayout();
            this.Panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // Panel1
            // 
            this.Panel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.Panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(118)))), ((int)(((byte)(221)))));
            this.Panel1.Controls.Add(this.btnCancel);
            this.Panel1.Controls.Add(this.btnVerify);
            this.Panel1.Controls.Add(this.txtPassword);
            this.Panel1.Controls.Add(this.btnMinimize);
            this.Panel1.Controls.Add(this.btnDeletePhone);
            this.Panel1.Controls.Add(this.btnCustomerRecords);
            this.Panel1.Controls.Add(this.btnStock);
            this.Panel1.Controls.Add(this.btnCustomers);
            this.Panel1.Controls.Add(this.btnAddNewPhone);
            this.Panel1.Controls.Add(this.btnExit);
            this.Panel1.Location = new System.Drawing.Point(4, 2);
            this.Panel1.Name = "Panel1";
            this.Panel1.Size = new System.Drawing.Size(276, 775);
            this.Panel1.TabIndex = 1;
            this.Panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.Panel1_Paint);
            this.Panel1.PreviewKeyDown += new System.Windows.Forms.PreviewKeyDownEventHandler(this.Panel1_PreviewKeyDown);
            // 
            // btnCancel
            // 
            this.btnCancel.CheckedState.Parent = this.btnCancel;
            this.btnCancel.CustomImages.Parent = this.btnCancel;
            this.btnCancel.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(118)))), ((int)(((byte)(221)))));
            this.btnCancel.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancel.ForeColor = System.Drawing.Color.White;
            this.btnCancel.HoverState.Parent = this.btnCancel;
            this.btnCancel.Location = new System.Drawing.Point(132, 469);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.ShadowDecoration.Parent = this.btnCancel;
            this.btnCancel.Size = new System.Drawing.Size(123, 45);
            this.btnCancel.TabIndex = 10;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnVerify
            // 
            this.btnVerify.CheckedState.Parent = this.btnVerify;
            this.btnVerify.CustomImages.Parent = this.btnVerify;
            this.btnVerify.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(118)))), ((int)(((byte)(221)))));
            this.btnVerify.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVerify.ForeColor = System.Drawing.Color.White;
            this.btnVerify.HoverState.Parent = this.btnVerify;
            this.btnVerify.Location = new System.Drawing.Point(9, 469);
            this.btnVerify.Name = "btnVerify";
            this.btnVerify.ShadowDecoration.Parent = this.btnVerify;
            this.btnVerify.Size = new System.Drawing.Size(117, 45);
            this.btnVerify.TabIndex = 9;
            this.btnVerify.Text = "Verify";
            this.btnVerify.Click += new System.EventHandler(this.btnVerify_Click);
            // 
            // txtPassword
            // 
            this.txtPassword.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtPassword.DefaultText = "";
            this.txtPassword.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtPassword.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtPassword.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtPassword.DisabledState.Parent = this.txtPassword;
            this.txtPassword.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtPassword.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(118)))), ((int)(((byte)(221)))));
            this.txtPassword.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtPassword.FocusedState.Parent = this.txtPassword;
            this.txtPassword.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPassword.ForeColor = System.Drawing.Color.White;
            this.txtPassword.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtPassword.HoverState.Parent = this.txtPassword;
            this.txtPassword.Location = new System.Drawing.Point(6, 417);
            this.txtPassword.Margin = new System.Windows.Forms.Padding(5);
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.PasswordChar = '*';
            this.txtPassword.PlaceholderText = "";
            this.txtPassword.SelectedText = "";
            this.txtPassword.ShadowDecoration.Parent = this.txtPassword;
            this.txtPassword.Size = new System.Drawing.Size(249, 44);
            this.txtPassword.TabIndex = 8;
            this.txtPassword.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // btnMinimize
            // 
            this.btnMinimize.CheckedState.Parent = this.btnMinimize;
            this.btnMinimize.CustomImages.Parent = this.btnMinimize;
            this.btnMinimize.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(118)))), ((int)(((byte)(221)))));
            this.btnMinimize.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnMinimize.ForeColor = System.Drawing.Color.White;
            this.btnMinimize.HoverState.Parent = this.btnMinimize;
            this.btnMinimize.Image = ((System.Drawing.Image)(resources.GetObject("btnMinimize.Image")));
            this.btnMinimize.ImageSize = new System.Drawing.Size(30, 30);
            this.btnMinimize.Location = new System.Drawing.Point(54, 11);
            this.btnMinimize.Name = "btnMinimize";
            this.btnMinimize.ShadowDecoration.Parent = this.btnMinimize;
            this.btnMinimize.Size = new System.Drawing.Size(39, 31);
            this.btnMinimize.TabIndex = 6;
            this.btnMinimize.Click += new System.EventHandler(this.btnMinimize_Click);
            // 
            // btnDeletePhone
            // 
            this.btnDeletePhone.BorderRadius = 26;
            this.btnDeletePhone.ButtonMode = Guna.UI2.WinForms.Enums.ButtonMode.RadioButton;
            this.btnDeletePhone.CheckedState.FillColor = System.Drawing.Color.White;
            this.btnDeletePhone.CheckedState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(118)))), ((int)(((byte)(221)))));
            this.btnDeletePhone.CheckedState.Parent = this.btnDeletePhone;
            this.btnDeletePhone.CustomImages.Parent = this.btnDeletePhone;
            this.btnDeletePhone.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(118)))), ((int)(((byte)(221)))));
            this.btnDeletePhone.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDeletePhone.ForeColor = System.Drawing.Color.White;
            this.btnDeletePhone.HoverState.Parent = this.btnDeletePhone;
            this.btnDeletePhone.Image = ((System.Drawing.Image)(resources.GetObject("btnDeletePhone.Image")));
            this.btnDeletePhone.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btnDeletePhone.ImageSize = new System.Drawing.Size(30, 30);
            this.btnDeletePhone.Location = new System.Drawing.Point(9, 362);
            this.btnDeletePhone.Name = "btnDeletePhone";
            this.btnDeletePhone.ShadowDecoration.Parent = this.btnDeletePhone;
            this.btnDeletePhone.Size = new System.Drawing.Size(264, 47);
            this.btnDeletePhone.TabIndex = 5;
            this.btnDeletePhone.Text = "Delete Phone Record";
            this.btnDeletePhone.Click += new System.EventHandler(this.btnDeletePhone_Click);
            // 
            // btnCustomerRecords
            // 
            this.btnCustomerRecords.BorderRadius = 26;
            this.btnCustomerRecords.ButtonMode = Guna.UI2.WinForms.Enums.ButtonMode.RadioButton;
            this.btnCustomerRecords.CheckedState.FillColor = System.Drawing.Color.White;
            this.btnCustomerRecords.CheckedState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(118)))), ((int)(((byte)(221)))));
            this.btnCustomerRecords.CheckedState.Parent = this.btnCustomerRecords;
            this.btnCustomerRecords.CustomImages.Parent = this.btnCustomerRecords;
            this.btnCustomerRecords.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(118)))), ((int)(((byte)(221)))));
            this.btnCustomerRecords.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCustomerRecords.ForeColor = System.Drawing.Color.White;
            this.btnCustomerRecords.HoverState.Parent = this.btnCustomerRecords;
            this.btnCustomerRecords.Image = ((System.Drawing.Image)(resources.GetObject("btnCustomerRecords.Image")));
            this.btnCustomerRecords.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btnCustomerRecords.ImageSize = new System.Drawing.Size(30, 30);
            this.btnCustomerRecords.Location = new System.Drawing.Point(9, 297);
            this.btnCustomerRecords.Name = "btnCustomerRecords";
            this.btnCustomerRecords.ShadowDecoration.Parent = this.btnCustomerRecords;
            this.btnCustomerRecords.Size = new System.Drawing.Size(264, 47);
            this.btnCustomerRecords.TabIndex = 4;
            this.btnCustomerRecords.Text = "Customer Records";
            this.btnCustomerRecords.Click += new System.EventHandler(this.btnCustomerRecords_Click);
            // 
            // btnStock
            // 
            this.btnStock.BorderRadius = 26;
            this.btnStock.ButtonMode = Guna.UI2.WinForms.Enums.ButtonMode.RadioButton;
            this.btnStock.CheckedState.FillColor = System.Drawing.Color.White;
            this.btnStock.CheckedState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(118)))), ((int)(((byte)(221)))));
            this.btnStock.CheckedState.Parent = this.btnStock;
            this.btnStock.CustomImages.Parent = this.btnStock;
            this.btnStock.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(118)))), ((int)(((byte)(221)))));
            this.btnStock.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnStock.ForeColor = System.Drawing.Color.White;
            this.btnStock.HoverState.Parent = this.btnStock;
            this.btnStock.Image = ((System.Drawing.Image)(resources.GetObject("btnStock.Image")));
            this.btnStock.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btnStock.ImageSize = new System.Drawing.Size(30, 30);
            this.btnStock.Location = new System.Drawing.Point(9, 232);
            this.btnStock.Name = "btnStock";
            this.btnStock.ShadowDecoration.Parent = this.btnStock;
            this.btnStock.Size = new System.Drawing.Size(264, 47);
            this.btnStock.TabIndex = 3;
            this.btnStock.Text = "Stock";
            this.btnStock.Click += new System.EventHandler(this.btnStock_Click);
            // 
            // btnCustomers
            // 
            this.btnCustomers.BorderRadius = 26;
            this.btnCustomers.ButtonMode = Guna.UI2.WinForms.Enums.ButtonMode.RadioButton;
            this.btnCustomers.CheckedState.FillColor = System.Drawing.Color.White;
            this.btnCustomers.CheckedState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(118)))), ((int)(((byte)(221)))));
            this.btnCustomers.CheckedState.Parent = this.btnCustomers;
            this.btnCustomers.CustomImages.Parent = this.btnCustomers;
            this.btnCustomers.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(118)))), ((int)(((byte)(221)))));
            this.btnCustomers.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCustomers.ForeColor = System.Drawing.Color.White;
            this.btnCustomers.HoverState.Parent = this.btnCustomers;
            this.btnCustomers.Image = ((System.Drawing.Image)(resources.GetObject("btnCustomers.Image")));
            this.btnCustomers.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btnCustomers.ImageSize = new System.Drawing.Size(30, 30);
            this.btnCustomers.Location = new System.Drawing.Point(9, 168);
            this.btnCustomers.Name = "btnCustomers";
            this.btnCustomers.ShadowDecoration.Parent = this.btnCustomers;
            this.btnCustomers.Size = new System.Drawing.Size(264, 47);
            this.btnCustomers.TabIndex = 2;
            this.btnCustomers.Text = "Customers";
            this.btnCustomers.Click += new System.EventHandler(this.btnCustomers_Click);
            // 
            // btnAddNewPhone
            // 
            this.btnAddNewPhone.BorderRadius = 26;
            this.btnAddNewPhone.ButtonMode = Guna.UI2.WinForms.Enums.ButtonMode.RadioButton;
            this.btnAddNewPhone.CheckedState.FillColor = System.Drawing.Color.White;
            this.btnAddNewPhone.CheckedState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(118)))), ((int)(((byte)(221)))));
            this.btnAddNewPhone.CheckedState.Parent = this.btnAddNewPhone;
            this.btnAddNewPhone.CustomImages.Parent = this.btnAddNewPhone;
            this.btnAddNewPhone.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(118)))), ((int)(((byte)(221)))));
            this.btnAddNewPhone.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddNewPhone.ForeColor = System.Drawing.Color.White;
            this.btnAddNewPhone.HoverState.Parent = this.btnAddNewPhone;
            this.btnAddNewPhone.Image = ((System.Drawing.Image)(resources.GetObject("btnAddNewPhone.Image")));
            this.btnAddNewPhone.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btnAddNewPhone.ImageSize = new System.Drawing.Size(30, 30);
            this.btnAddNewPhone.Location = new System.Drawing.Point(9, 104);
            this.btnAddNewPhone.Name = "btnAddNewPhone";
            this.btnAddNewPhone.ShadowDecoration.Parent = this.btnAddNewPhone;
            this.btnAddNewPhone.Size = new System.Drawing.Size(264, 47);
            this.btnAddNewPhone.TabIndex = 1;
            this.btnAddNewPhone.Text = "Add New Phone";
            this.btnAddNewPhone.Click += new System.EventHandler(this.btnAddNewPhone_Click);
            // 
            // btnExit
            // 
            this.btnExit.CheckedState.Parent = this.btnExit;
            this.btnExit.CustomImages.Parent = this.btnExit;
            this.btnExit.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(118)))), ((int)(((byte)(221)))));
            this.btnExit.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnExit.ForeColor = System.Drawing.Color.White;
            this.btnExit.HoverState.Parent = this.btnExit;
            this.btnExit.Image = ((System.Drawing.Image)(resources.GetObject("btnExit.Image")));
            this.btnExit.ImageSize = new System.Drawing.Size(30, 30);
            this.btnExit.Location = new System.Drawing.Point(9, 11);
            this.btnExit.Name = "btnExit";
            this.btnExit.ShadowDecoration.Parent = this.btnExit;
            this.btnExit.Size = new System.Drawing.Size(39, 31);
            this.btnExit.TabIndex = 0;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // Panel2
            // 
            this.Panel2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.Panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(118)))), ((int)(((byte)(221)))));
            this.Panel2.Controls.Add(this.uC_Login1);
            this.Panel2.Controls.Add(this.uC_DeletePhoneRecord1);
            this.Panel2.Controls.Add(this.uC_CustomerRecords1);
            this.Panel2.Controls.Add(this.uC_Stock1);
            this.Panel2.Controls.Add(this.uC_Customer1);
            this.Panel2.Controls.Add(this.uC_AddNewPhone1);
            this.Panel2.Location = new System.Drawing.Point(286, 2);
            this.Panel2.Name = "Panel2";
            this.Panel2.Size = new System.Drawing.Size(1292, 775);
            this.Panel2.TabIndex = 2;
            this.Panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.Panel2_Paint);
            // 
            // guna2Elipse1
            // 
            this.guna2Elipse1.BorderRadius = 30;
            this.guna2Elipse1.TargetControl = this;
            // 
            // guna2Elipse2
            // 
            this.guna2Elipse2.BorderRadius = 26;
            this.guna2Elipse2.TargetControl = this;
            // 
            // guna2Elipse3
            // 
            this.guna2Elipse3.BorderRadius = 26;
            this.guna2Elipse3.TargetControl = this.Panel2;
            // 
            // guna2Elipse4
            // 
            this.guna2Elipse4.BorderRadius = 30;
            this.guna2Elipse4.TargetControl = this;
            // 
            // guna2Elipse5
            // 
            this.guna2Elipse5.BorderRadius = 30;
            this.guna2Elipse5.TargetControl = this.Panel2;
            // 
            // guna2Elipse6
            // 
            this.guna2Elipse6.BorderRadius = 30;
            this.guna2Elipse6.TargetControl = this.Panel2;
            // 
            // uC_Login1
            // 
            this.uC_Login1.AutoSize = true;
            this.uC_Login1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(118)))), ((int)(((byte)(221)))));
            this.uC_Login1.Location = new System.Drawing.Point(0, -1);
            this.uC_Login1.Margin = new System.Windows.Forms.Padding(4);
            this.uC_Login1.Name = "uC_Login1";
            this.uC_Login1.Size = new System.Drawing.Size(1579, 1016);
            this.uC_Login1.TabIndex = 5;
            this.uC_Login1.VisibleChanged += new System.EventHandler(this.uC_Login1_VisibleChanged);
            // 
            // uC_DeletePhoneRecord1
            // 
            this.uC_DeletePhoneRecord1.AutoSize = true;
            this.uC_DeletePhoneRecord1.BackColor = System.Drawing.Color.White;
            this.uC_DeletePhoneRecord1.Location = new System.Drawing.Point(0, 0);
            this.uC_DeletePhoneRecord1.Margin = new System.Windows.Forms.Padding(4);
            this.uC_DeletePhoneRecord1.Name = "uC_DeletePhoneRecord1";
            this.uC_DeletePhoneRecord1.Size = new System.Drawing.Size(1526, 1012);
            this.uC_DeletePhoneRecord1.TabIndex = 4;
            // 
            // uC_CustomerRecords1
            // 
            this.uC_CustomerRecords1.AutoSize = true;
            this.uC_CustomerRecords1.BackColor = System.Drawing.Color.White;
            this.uC_CustomerRecords1.Location = new System.Drawing.Point(-2, -1);
            this.uC_CustomerRecords1.Margin = new System.Windows.Forms.Padding(4);
            this.uC_CustomerRecords1.Name = "uC_CustomerRecords1";
            this.uC_CustomerRecords1.Size = new System.Drawing.Size(1527, 1012);
            this.uC_CustomerRecords1.TabIndex = 3;
            // 
            // uC_Stock1
            // 
            this.uC_Stock1.AllowDrop = true;
            this.uC_Stock1.AutoSize = true;
            this.uC_Stock1.BackColor = System.Drawing.Color.White;
            this.uC_Stock1.Location = new System.Drawing.Point(0, 0);
            this.uC_Stock1.Margin = new System.Windows.Forms.Padding(4);
            this.uC_Stock1.Name = "uC_Stock1";
            this.uC_Stock1.Size = new System.Drawing.Size(1541, 1016);
            this.uC_Stock1.TabIndex = 2;
            // 
            // uC_Customer1
            // 
            this.uC_Customer1.AutoSize = true;
            this.uC_Customer1.BackColor = System.Drawing.Color.White;
            this.uC_Customer1.Location = new System.Drawing.Point(1, 0);
            this.uC_Customer1.Margin = new System.Windows.Forms.Padding(4);
            this.uC_Customer1.Name = "uC_Customer1";
            this.uC_Customer1.Size = new System.Drawing.Size(1461, 1016);
            this.uC_Customer1.TabIndex = 1;
            this.uC_Customer1.Load += new System.EventHandler(this.uC_Customer1_Load);
            // 
            // uC_AddNewPhone1
            // 
            this.uC_AddNewPhone1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.uC_AddNewPhone1.BackColor = System.Drawing.Color.White;
            this.uC_AddNewPhone1.Location = new System.Drawing.Point(-2, 0);
            this.uC_AddNewPhone1.Margin = new System.Windows.Forms.Padding(4);
            this.uC_AddNewPhone1.Name = "uC_AddNewPhone1";
            this.uC_AddNewPhone1.Size = new System.Drawing.Size(1292, 774);
            this.uC_AddNewPhone1.TabIndex = 0;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 21F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(118)))), ((int)(((byte)(221)))));
            this.ClientSize = new System.Drawing.Size(1579, 779);
            this.Controls.Add(this.Panel2);
            this.Controls.Add(this.Panel1);
            this.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Form1_Load);
            this.Panel1.ResumeLayout(false);
            this.Panel2.ResumeLayout(false);
            this.Panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        internal System.Windows.Forms.Panel Panel1;
        private Guna.UI2.WinForms.Guna2Button btnExit;
        internal System.Windows.Forms.Panel Panel2;
        private Guna.UI2.WinForms.Guna2Button btnAddNewPhone;
        private Guna.UI2.WinForms.Guna2Button btnDeletePhone;
        private Guna.UI2.WinForms.Guna2Button btnCustomerRecords;
        private Guna.UI2.WinForms.Guna2Button btnStock;
        private Guna.UI2.WinForms.Guna2Button btnCustomers;
        private Guna.UI2.WinForms.Guna2Button btnMinimize;
        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse1;
        private AllUserControl.UC_AddNewPhone uC_AddNewPhone1;
        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse2;
        private AllUserControl.UC_Customer uC_Customer1;
        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse3;
        private AllUserControl.UC_Stock uC_Stock1;
        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse4;
        private AllUserControl.UC_CustomerRecords uC_CustomerRecords1;
        private Guna.UI2.WinForms.Guna2Button btnCancel;
        private Guna.UI2.WinForms.Guna2Button btnVerify;
        private Guna.UI2.WinForms.Guna2TextBox txtPassword;
        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse5;
        private AllUserControl.UC_DeletePhoneRecord uC_DeletePhoneRecord1;
        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse6;
        private AllUserControl.UC_Login uC_Login1;

    }
}

