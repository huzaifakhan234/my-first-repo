﻿namespace mobileShop.AllUserControl
{
    partial class UC_AddNewPhone
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UC_AddNewPhone));
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtCompany = new Guna.UI2.WinForms.Guna2TextBox();
            this.txtModel = new Guna.UI2.WinForms.Guna2TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtPrice = new Guna.UI2.WinForms.Guna2TextBox();
            this.Label13 = new System.Windows.Forms.Label();
            this.txtNetwork = new Guna.UI2.WinForms.Guna2ComboBox();
            this.Label12 = new System.Windows.Forms.Label();
            this.txtSim = new Guna.UI2.WinForms.Guna2ComboBox();
            this.Label11 = new System.Windows.Forms.Label();
            this.txtFingerprint = new Guna.UI2.WinForms.Guna2ComboBox();
            this.Label10 = new System.Windows.Forms.Label();
            this.txtFront = new Guna.UI2.WinForms.Guna2ComboBox();
            this.Label9 = new System.Windows.Forms.Label();
            this.txtRear = new Guna.UI2.WinForms.Guna2ComboBox();
            this.Label8 = new System.Windows.Forms.Label();
            this.txtDisplay = new Guna.UI2.WinForms.Guna2ComboBox();
            this.Label7 = new System.Windows.Forms.Label();
            this.txtExpandable = new Guna.UI2.WinForms.Guna2ComboBox();
            this.Label6 = new System.Windows.Forms.Label();
            this.txtInternal = new Guna.UI2.WinForms.Guna2ComboBox();
            this.Label5 = new System.Windows.Forms.Label();
            this.txtRam = new Guna.UI2.WinForms.Guna2ComboBox();
            this.Label4 = new System.Windows.Forms.Label();
            this.btnReset = new Guna.UI2.WinForms.Guna2Button();
            this.btnSave = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Elipse1 = new Guna.UI2.WinForms.Guna2Elipse(this.components);
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Century Gothic", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Image = ((System.Drawing.Image)(resources.GetObject("label1.Image")));
            this.label1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label1.Location = new System.Drawing.Point(3, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(365, 85);
            this.label1.TabIndex = 0;
            this.label1.Text = "New Phone Record";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(31, 92);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(91, 24);
            this.label2.TabIndex = 1;
            this.label2.Text = "Company";
            // 
            // txtCompany
            // 
            this.txtCompany.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtCompany.DefaultText = "";
            this.txtCompany.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtCompany.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtCompany.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtCompany.DisabledState.Parent = this.txtCompany;
            this.txtCompany.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtCompany.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtCompany.FocusedState.Parent = this.txtCompany;
            this.txtCompany.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCompany.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtCompany.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtCompany.HoverState.Parent = this.txtCompany;
            this.txtCompany.Location = new System.Drawing.Point(35, 122);
            this.txtCompany.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.txtCompany.Name = "txtCompany";
            this.txtCompany.PasswordChar = '\0';
            this.txtCompany.PlaceholderText = "";
            this.txtCompany.SelectedText = "";
            this.txtCompany.ShadowDecoration.Parent = this.txtCompany;
            this.txtCompany.Size = new System.Drawing.Size(528, 52);
            this.txtCompany.Style = Guna.UI2.WinForms.Enums.TextBoxStyle.Material;
            this.txtCompany.TabIndex = 2;
            // 
            // txtModel
            // 
            this.txtModel.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtModel.DefaultText = "";
            this.txtModel.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtModel.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtModel.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtModel.DisabledState.Parent = this.txtModel;
            this.txtModel.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtModel.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtModel.FocusedState.Parent = this.txtModel;
            this.txtModel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtModel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtModel.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtModel.HoverState.Parent = this.txtModel;
            this.txtModel.Location = new System.Drawing.Point(35, 219);
            this.txtModel.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.txtModel.Name = "txtModel";
            this.txtModel.PasswordChar = '\0';
            this.txtModel.PlaceholderText = "";
            this.txtModel.SelectedText = "";
            this.txtModel.ShadowDecoration.Parent = this.txtModel;
            this.txtModel.Size = new System.Drawing.Size(528, 52);
            this.txtModel.Style = Guna.UI2.WinForms.Enums.TextBoxStyle.Material;
            this.txtModel.TabIndex = 4;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(31, 189);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(119, 24);
            this.label3.TabIndex = 3;
            this.label3.Text = "Model Name";
            // 
            // txtPrice
            // 
            this.txtPrice.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtPrice.DefaultText = "";
            this.txtPrice.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtPrice.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtPrice.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtPrice.DisabledState.Parent = this.txtPrice;
            this.txtPrice.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtPrice.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtPrice.FocusedState.Parent = this.txtPrice;
            this.txtPrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPrice.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtPrice.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtPrice.HoverState.Parent = this.txtPrice;
            this.txtPrice.Location = new System.Drawing.Point(665, 590);
            this.txtPrice.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.txtPrice.Name = "txtPrice";
            this.txtPrice.PasswordChar = '\0';
            this.txtPrice.PlaceholderText = "";
            this.txtPrice.SelectedText = "";
            this.txtPrice.ShadowDecoration.Parent = this.txtPrice;
            this.txtPrice.Size = new System.Drawing.Size(528, 52);
            this.txtPrice.Style = Guna.UI2.WinForms.Enums.TextBoxStyle.Material;
            this.txtPrice.TabIndex = 35;
            this.txtPrice.TextChanged += new System.EventHandler(this.txtPrice_TextChanged);
            // 
            // Label13
            // 
            this.Label13.AutoSize = true;
            this.Label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label13.Location = new System.Drawing.Point(661, 553);
            this.Label13.Name = "Label13";
            this.Label13.Size = new System.Drawing.Size(53, 24);
            this.Label13.TabIndex = 34;
            this.Label13.Text = "Price";
            // 
            // txtNetwork
            // 
            this.txtNetwork.BackColor = System.Drawing.Color.Transparent;
            this.txtNetwork.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.txtNetwork.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.txtNetwork.FocusedColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtNetwork.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtNetwork.FocusedState.Parent = this.txtNetwork;
            this.txtNetwork.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNetwork.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtNetwork.HoverState.Parent = this.txtNetwork;
            this.txtNetwork.ItemHeight = 30;
            this.txtNetwork.Items.AddRange(new object[] {
            "3G",
            "3G & 4G",
            "3G, 4G & 5G",
            "4G & 5G"});
            this.txtNetwork.ItemsAppearance.Parent = this.txtNetwork;
            this.txtNetwork.Location = new System.Drawing.Point(665, 492);
            this.txtNetwork.Name = "txtNetwork";
            this.txtNetwork.ShadowDecoration.Parent = this.txtNetwork;
            this.txtNetwork.Size = new System.Drawing.Size(528, 36);
            this.txtNetwork.Style = Guna.UI2.WinForms.Enums.TextBoxStyle.Material;
            this.txtNetwork.TabIndex = 33;
            // 
            // Label12
            // 
            this.Label12.AutoSize = true;
            this.Label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label12.Location = new System.Drawing.Point(661, 464);
            this.Label12.Name = "Label12";
            this.Label12.Size = new System.Drawing.Size(127, 24);
            this.Label12.TabIndex = 32;
            this.Label12.Text = "Network Type";
            // 
            // txtSim
            // 
            this.txtSim.BackColor = System.Drawing.Color.Transparent;
            this.txtSim.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.txtSim.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.txtSim.FocusedColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtSim.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtSim.FocusedState.Parent = this.txtSim;
            this.txtSim.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSim.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtSim.HoverState.Parent = this.txtSim;
            this.txtSim.ItemHeight = 30;
            this.txtSim.Items.AddRange(new object[] {
            "Single SIM",
            "Dual SIM"});
            this.txtSim.ItemsAppearance.Parent = this.txtSim;
            this.txtSim.Location = new System.Drawing.Point(665, 407);
            this.txtSim.Name = "txtSim";
            this.txtSim.ShadowDecoration.Parent = this.txtSim;
            this.txtSim.Size = new System.Drawing.Size(528, 36);
            this.txtSim.Style = Guna.UI2.WinForms.Enums.TextBoxStyle.Material;
            this.txtSim.TabIndex = 31;
            // 
            // Label11
            // 
            this.Label11.AutoSize = true;
            this.Label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label11.Location = new System.Drawing.Point(661, 367);
            this.Label11.Name = "Label11";
            this.Label11.Size = new System.Drawing.Size(90, 24);
            this.Label11.TabIndex = 30;
            this.Label11.Text = "Sim Type";
            // 
            // txtFingerprint
            // 
            this.txtFingerprint.BackColor = System.Drawing.Color.Transparent;
            this.txtFingerprint.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.txtFingerprint.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.txtFingerprint.FocusedColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtFingerprint.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtFingerprint.FocusedState.Parent = this.txtFingerprint;
            this.txtFingerprint.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFingerprint.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtFingerprint.HoverState.Parent = this.txtFingerprint;
            this.txtFingerprint.ItemHeight = 30;
            this.txtFingerprint.Items.AddRange(new object[] {
            "YES",
            "NO"});
            this.txtFingerprint.ItemsAppearance.Parent = this.txtFingerprint;
            this.txtFingerprint.Location = new System.Drawing.Point(665, 326);
            this.txtFingerprint.Name = "txtFingerprint";
            this.txtFingerprint.ShadowDecoration.Parent = this.txtFingerprint;
            this.txtFingerprint.Size = new System.Drawing.Size(528, 36);
            this.txtFingerprint.Style = Guna.UI2.WinForms.Enums.TextBoxStyle.Material;
            this.txtFingerprint.TabIndex = 29;
            // 
            // Label10
            // 
            this.Label10.AutoSize = true;
            this.Label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label10.Location = new System.Drawing.Point(661, 277);
            this.Label10.Name = "Label10";
            this.Label10.Size = new System.Drawing.Size(166, 24);
            this.Label10.TabIndex = 28;
            this.Label10.Text = "Fingerprint Sensor";
            // 
            // txtFront
            // 
            this.txtFront.BackColor = System.Drawing.Color.Transparent;
            this.txtFront.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.txtFront.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.txtFront.FocusedColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtFront.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtFront.FocusedState.Parent = this.txtFront;
            this.txtFront.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFront.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtFront.HoverState.Parent = this.txtFront;
            this.txtFront.ItemHeight = 30;
            this.txtFront.Items.AddRange(new object[] {
            "2 MP ",
            "3 MP ",
            "5 MP",
            "13 MP "});
            this.txtFront.ItemsAppearance.Parent = this.txtFront;
            this.txtFront.Location = new System.Drawing.Point(665, 235);
            this.txtFront.Name = "txtFront";
            this.txtFront.ShadowDecoration.Parent = this.txtFront;
            this.txtFront.Size = new System.Drawing.Size(528, 36);
            this.txtFront.Style = Guna.UI2.WinForms.Enums.TextBoxStyle.Material;
            this.txtFront.TabIndex = 27;
            // 
            // Label9
            // 
            this.Label9.AutoSize = true;
            this.Label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label9.Location = new System.Drawing.Point(661, 189);
            this.Label9.Name = "Label9";
            this.Label9.Size = new System.Drawing.Size(125, 24);
            this.Label9.TabIndex = 26;
            this.Label9.Text = "Front Camera";
            // 
            // txtRear
            // 
            this.txtRear.BackColor = System.Drawing.Color.Transparent;
            this.txtRear.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.txtRear.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.txtRear.FocusedColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtRear.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtRear.FocusedState.Parent = this.txtRear;
            this.txtRear.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRear.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtRear.HoverState.Parent = this.txtRear;
            this.txtRear.ItemHeight = 30;
            this.txtRear.Items.AddRange(new object[] {
            "3 MP",
            "5 MP",
            "7 MP",
            "10 MP",
            "13 MP",
            "15 MP",
            "17 MP",
            "20 MP",
            "50 MP",
            "100 MP",
            "120 MP"});
            this.txtRear.ItemsAppearance.Parent = this.txtRear;
            this.txtRear.Location = new System.Drawing.Point(665, 138);
            this.txtRear.Name = "txtRear";
            this.txtRear.ShadowDecoration.Parent = this.txtRear;
            this.txtRear.Size = new System.Drawing.Size(528, 36);
            this.txtRear.Style = Guna.UI2.WinForms.Enums.TextBoxStyle.Material;
            this.txtRear.TabIndex = 25;
            this.txtRear.SelectedIndexChanged += new System.EventHandler(this.txtRear_SelectedIndexChanged);
            // 
            // Label8
            // 
            this.Label8.AutoSize = true;
            this.Label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label8.Location = new System.Drawing.Point(661, 92);
            this.Label8.Name = "Label8";
            this.Label8.Size = new System.Drawing.Size(121, 24);
            this.Label8.TabIndex = 36;
            this.Label8.Text = "Rear Camera";
            // 
            // txtDisplay
            // 
            this.txtDisplay.BackColor = System.Drawing.Color.Transparent;
            this.txtDisplay.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.txtDisplay.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.txtDisplay.FocusedColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtDisplay.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtDisplay.FocusedState.Parent = this.txtDisplay;
            this.txtDisplay.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDisplay.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtDisplay.HoverState.Parent = this.txtDisplay;
            this.txtDisplay.ItemHeight = 30;
            this.txtDisplay.Items.AddRange(new object[] {
            "4.0 inch",
            "4.5 inch",
            "4.7 inch",
            "5.0 inch",
            "5.2 inch ",
            "5.5 inch",
            "5.7 inch ",
            "5.8 inch",
            "6.0 inch",
            "6.1 inch",
            "6.2 inch",
            "6.3 inch",
            "6.4 inch",
            "6.5 inch",
            "6.7 inch"});
            this.txtDisplay.ItemsAppearance.Parent = this.txtDisplay;
            this.txtDisplay.Location = new System.Drawing.Point(35, 606);
            this.txtDisplay.Name = "txtDisplay";
            this.txtDisplay.ShadowDecoration.Parent = this.txtDisplay;
            this.txtDisplay.Size = new System.Drawing.Size(528, 36);
            this.txtDisplay.Style = Guna.UI2.WinForms.Enums.TextBoxStyle.Material;
            this.txtDisplay.TabIndex = 44;
            // 
            // Label7
            // 
            this.Label7.AutoSize = true;
            this.Label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label7.Location = new System.Drawing.Point(31, 553);
            this.Label7.Name = "Label7";
            this.Label7.Size = new System.Drawing.Size(111, 24);
            this.Label7.TabIndex = 43;
            this.Label7.Text = "Display Size";
            // 
            // txtExpandable
            // 
            this.txtExpandable.BackColor = System.Drawing.Color.Transparent;
            this.txtExpandable.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.txtExpandable.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.txtExpandable.FocusedColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtExpandable.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtExpandable.FocusedState.Parent = this.txtExpandable;
            this.txtExpandable.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtExpandable.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtExpandable.HoverState.Parent = this.txtExpandable;
            this.txtExpandable.ItemHeight = 30;
            this.txtExpandable.Items.AddRange(new object[] {
            "1 GB",
            "2 GB  ",
            "4 GB",
            "8 GB",
            "16 GB",
            "32 GB",
            "64 GB",
            "128 GB",
            "256 GB",
            "512 GB ",
            "1 TB"});
            this.txtExpandable.ItemsAppearance.Parent = this.txtExpandable;
            this.txtExpandable.Location = new System.Drawing.Point(35, 492);
            this.txtExpandable.Name = "txtExpandable";
            this.txtExpandable.ShadowDecoration.Parent = this.txtExpandable;
            this.txtExpandable.Size = new System.Drawing.Size(528, 36);
            this.txtExpandable.Style = Guna.UI2.WinForms.Enums.TextBoxStyle.Material;
            this.txtExpandable.TabIndex = 42;
            // 
            // Label6
            // 
            this.Label6.AutoSize = true;
            this.Label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label6.Location = new System.Drawing.Point(31, 464);
            this.Label6.Name = "Label6";
            this.Label6.Size = new System.Drawing.Size(182, 24);
            this.Label6.TabIndex = 41;
            this.Label6.Text = "Expandable Storage";
            // 
            // txtInternal
            // 
            this.txtInternal.BackColor = System.Drawing.Color.Transparent;
            this.txtInternal.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.txtInternal.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.txtInternal.FocusedColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtInternal.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtInternal.FocusedState.Parent = this.txtInternal;
            this.txtInternal.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtInternal.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtInternal.HoverState.Parent = this.txtInternal;
            this.txtInternal.ItemHeight = 30;
            this.txtInternal.Items.AddRange(new object[] {
            "1 GB",
            "2 GB  ",
            "4 GB",
            "8 GB",
            "16 GB",
            "32 GB",
            "64 GB",
            "128 GB",
            "256 GB",
            "512 GB ",
            "1 TB"});
            this.txtInternal.ItemsAppearance.Parent = this.txtInternal;
            this.txtInternal.Location = new System.Drawing.Point(35, 407);
            this.txtInternal.Name = "txtInternal";
            this.txtInternal.ShadowDecoration.Parent = this.txtInternal;
            this.txtInternal.Size = new System.Drawing.Size(528, 36);
            this.txtInternal.Style = Guna.UI2.WinForms.Enums.TextBoxStyle.Material;
            this.txtInternal.TabIndex = 40;
            // 
            // Label5
            // 
            this.Label5.AutoSize = true;
            this.Label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label5.Location = new System.Drawing.Point(31, 367);
            this.Label5.Name = "Label5";
            this.Label5.Size = new System.Drawing.Size(141, 24);
            this.Label5.TabIndex = 39;
            this.Label5.Text = "Internal Storage";
            // 
            // txtRam
            // 
            this.txtRam.BackColor = System.Drawing.Color.Transparent;
            this.txtRam.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.txtRam.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.txtRam.FocusedColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtRam.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtRam.FocusedState.Parent = this.txtRam;
            this.txtRam.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRam.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtRam.HoverState.Parent = this.txtRam;
            this.txtRam.ItemHeight = 30;
            this.txtRam.Items.AddRange(new object[] {
            "1 GB",
            "2 GB ",
            "3 GB ",
            "4 GB",
            "8 GB",
            "16 GB"});
            this.txtRam.ItemsAppearance.Parent = this.txtRam;
            this.txtRam.Location = new System.Drawing.Point(35, 326);
            this.txtRam.Name = "txtRam";
            this.txtRam.ShadowDecoration.Parent = this.txtRam;
            this.txtRam.Size = new System.Drawing.Size(528, 36);
            this.txtRam.Style = Guna.UI2.WinForms.Enums.TextBoxStyle.Material;
            this.txtRam.TabIndex = 38;
            // 
            // Label4
            // 
            this.Label4.AutoSize = true;
            this.Label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label4.Location = new System.Drawing.Point(31, 277);
            this.Label4.Name = "Label4";
            this.Label4.Size = new System.Drawing.Size(52, 24);
            this.Label4.TabIndex = 37;
            this.Label4.Text = "RAM";
            // 
            // btnReset
            // 
            this.btnReset.BorderRadius = 26;
            this.btnReset.BorderThickness = 1;
            this.btnReset.ButtonMode = Guna.UI2.WinForms.Enums.ButtonMode.RadioButton;
            this.btnReset.CheckedState.BorderColor = System.Drawing.Color.Black;
            this.btnReset.CheckedState.FillColor = System.Drawing.Color.White;
            this.btnReset.CheckedState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(118)))), ((int)(((byte)(221)))));
            this.btnReset.CheckedState.Parent = this.btnReset;
            this.btnReset.CustomImages.Parent = this.btnReset;
            this.btnReset.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(118)))), ((int)(((byte)(221)))));
            this.btnReset.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReset.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnReset.HoverState.Parent = this.btnReset;
            this.btnReset.Image = ((System.Drawing.Image)(resources.GetObject("btnReset.Image")));
            this.btnReset.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btnReset.ImageSize = new System.Drawing.Size(30, 30);
            this.btnReset.Location = new System.Drawing.Point(1080, 651);
            this.btnReset.Name = "btnReset";
            this.btnReset.ShadowDecoration.Parent = this.btnReset;
            this.btnReset.Size = new System.Drawing.Size(112, 45);
            this.btnReset.TabIndex = 46;
            this.btnReset.Text = "Reset";
            this.btnReset.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // btnSave
            // 
            this.btnSave.BorderRadius = 26;
            this.btnSave.BorderThickness = 1;
            this.btnSave.ButtonMode = Guna.UI2.WinForms.Enums.ButtonMode.RadioButton;
            this.btnSave.CheckedState.BorderColor = System.Drawing.Color.Black;
            this.btnSave.CheckedState.FillColor = System.Drawing.Color.White;
            this.btnSave.CheckedState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(118)))), ((int)(((byte)(221)))));
            this.btnSave.CheckedState.Parent = this.btnSave;
            this.btnSave.CustomImages.Parent = this.btnSave;
            this.btnSave.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(118)))), ((int)(((byte)(221)))));
            this.btnSave.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.ForeColor = System.Drawing.Color.White;
            this.btnSave.HoverState.Parent = this.btnSave;
            this.btnSave.Image = ((System.Drawing.Image)(resources.GetObject("btnSave.Image")));
            this.btnSave.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btnSave.ImageSize = new System.Drawing.Size(30, 30);
            this.btnSave.Location = new System.Drawing.Point(955, 651);
            this.btnSave.Name = "btnSave";
            this.btnSave.ShadowDecoration.Parent = this.btnSave;
            this.btnSave.Size = new System.Drawing.Size(109, 45);
            this.btnSave.TabIndex = 45;
            this.btnSave.Text = "Save";
            this.btnSave.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // guna2Elipse1
            // 
            this.guna2Elipse1.BorderRadius = 26;
            this.guna2Elipse1.TargetControl = this;
            // 
            // UC_AddNewPhone
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.btnReset);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.txtDisplay);
            this.Controls.Add(this.Label7);
            this.Controls.Add(this.txtExpandable);
            this.Controls.Add(this.Label6);
            this.Controls.Add(this.txtInternal);
            this.Controls.Add(this.Label5);
            this.Controls.Add(this.txtRam);
            this.Controls.Add(this.Label4);
            this.Controls.Add(this.Label8);
            this.Controls.Add(this.txtPrice);
            this.Controls.Add(this.Label13);
            this.Controls.Add(this.txtNetwork);
            this.Controls.Add(this.Label12);
            this.Controls.Add(this.txtSim);
            this.Controls.Add(this.Label11);
            this.Controls.Add(this.txtFingerprint);
            this.Controls.Add(this.Label10);
            this.Controls.Add(this.txtFront);
            this.Controls.Add(this.Label9);
            this.Controls.Add(this.txtRear);
            this.Controls.Add(this.txtModel);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtCompany);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "UC_AddNewPhone";
            this.Size = new System.Drawing.Size(1249, 775);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private Guna.UI2.WinForms.Guna2TextBox txtCompany;
        private Guna.UI2.WinForms.Guna2TextBox txtModel;
        private System.Windows.Forms.Label label3;
        internal Guna.UI2.WinForms.Guna2TextBox txtPrice;
        internal System.Windows.Forms.Label Label13;
        internal Guna.UI2.WinForms.Guna2ComboBox txtNetwork;
        internal System.Windows.Forms.Label Label12;
        internal Guna.UI2.WinForms.Guna2ComboBox txtSim;
        internal System.Windows.Forms.Label Label11;
        internal Guna.UI2.WinForms.Guna2ComboBox txtFingerprint;
        internal System.Windows.Forms.Label Label10;
        internal Guna.UI2.WinForms.Guna2ComboBox txtFront;
        internal System.Windows.Forms.Label Label9;
        internal Guna.UI2.WinForms.Guna2ComboBox txtRear;
        internal System.Windows.Forms.Label Label8;
        internal Guna.UI2.WinForms.Guna2ComboBox txtDisplay;
        internal System.Windows.Forms.Label Label7;
        internal Guna.UI2.WinForms.Guna2ComboBox txtExpandable;
        internal System.Windows.Forms.Label Label6;
        internal Guna.UI2.WinForms.Guna2ComboBox txtInternal;
        internal System.Windows.Forms.Label Label5;
        internal Guna.UI2.WinForms.Guna2ComboBox txtRam;
        internal System.Windows.Forms.Label Label4;
        internal Guna.UI2.WinForms.Guna2Button btnReset;
        internal Guna.UI2.WinForms.Guna2Button btnSave;
        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse1;
    }
}
